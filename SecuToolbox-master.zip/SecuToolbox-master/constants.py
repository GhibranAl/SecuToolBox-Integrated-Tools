# constants.py

# Reset
RESET = '\033[0m'

# Styles
BOLD = '\033[1m'

# Colors
LCYAN = '\033[96m'  # Light Cyan
RED = '\033[91m'    # Red
LPURPLE = '\033[94m' # Light Purple
GREEN = '\033[92m'  # Green
